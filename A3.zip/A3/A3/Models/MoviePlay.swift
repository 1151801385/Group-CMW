//
//  MoviePlay.swift
//  A3
//
//  Created by Wangyang on 2022/5/13.
//

import Foundation


struct MoviePlay {
    var place: String
    var time: String
}




