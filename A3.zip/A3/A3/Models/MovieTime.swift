//
//  MovieTime.swift
//  A3
//
//  Created by Wangyang on 2022/5/13.
//

import Foundation
struct MovieTime {
    var isSel: Bool
    var time: String
}
