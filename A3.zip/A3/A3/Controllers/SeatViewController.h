//
//  SeatViewController.h
//  A3
//
//  Created by 李志超 on 2022/5/19.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SeatViewController : UIViewController

@property (nonatomic,strong)NSString *movietitle;
@property (nonatomic,strong)UIImage *movieimage;
@property (nonatomic,strong)NSString *movieintroduction;
@property (nonatomic,strong)NSString *dateStr;
@property (nonatomic,strong)NSString *placeStr;
@property (nonatomic,strong)NSString *timeStr;

@end

NS_ASSUME_NONNULL_END
