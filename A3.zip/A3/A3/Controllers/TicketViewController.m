//
//  TicketViewController.m
//  A3
//
//  Created by 李志超 on 2022/5/20.
//

#import "TicketViewController.h"

@interface TicketViewController ()

@end

@implementation TicketViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.title = self.movietitle;
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    
    
    UILabel *ticketLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 100, self.view.frame.size.width, 30)];
    ticketLabel.text = @"YOUR TICKET";
    ticketLabel.font = [UIFont systemFontOfSize:20];
//    ticketLabel.textColor = [UIColor darkGrayColor];
    ticketLabel.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:ticketLabel];
    
    
    UIImageView *bgVIew = [[UIImageView alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2-50, 150, 100, 100/13*3.4)];
    bgVIew.image = [UIImage imageNamed:@"bg2"];
//    bgVIew.backgroundColor = [UIColor colorWithRed:240 green:244 blue:250 alpha:1];
    [self.view addSubview:bgVIew];
    
    UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(15, 200, 100, 140)];
    imageView.image = self.movieimage;
    [self.view addSubview:imageView];
    
    UILabel *movieTitleLabel = [[UILabel alloc]initWithFrame:CGRectMake(imageView.frame.origin.x+imageView.frame.size.width+15, imageView.frame.origin.y, self.view.frame.size.width-100-50, 60)];
    movieTitleLabel.font = [UIFont boldSystemFontOfSize:24];
    movieTitleLabel.numberOfLines = 0;
    movieTitleLabel.text = self.movietitle;
    [self.view addSubview:movieTitleLabel];
    
    UILabel *dateLabel = [[UILabel alloc]initWithFrame:CGRectMake(movieTitleLabel.frame.origin.x, movieTitleLabel.frame.origin.y+movieTitleLabel.frame.size.height, movieTitleLabel.frame.size.width, 20)];
    dateLabel.text = [NSString stringWithFormat:@"DATE:%@",self.dateStr];
    dateLabel.font = [UIFont systemFontOfSize:14];
    dateLabel.textColor = [UIColor darkGrayColor];
    [self.view addSubview:dateLabel];
    
    UILabel *timeLabel = [[UILabel alloc]initWithFrame:CGRectMake(dateLabel.frame.origin.x, dateLabel.frame.origin.y+dateLabel.frame.size.height, dateLabel.frame.size.width, 20)];
    timeLabel.text = [NSString stringWithFormat:@"TIME:%@",self.timeStr];
    timeLabel.font = [UIFont systemFontOfSize:14];
    timeLabel.textColor = [UIColor darkGrayColor];
    [self.view addSubview:timeLabel];
    
    NSLog(@"%@",self.selecetedSeats);
    UILabel *seatLabel = [[UILabel alloc]initWithFrame:CGRectMake(timeLabel.frame.origin.x, timeLabel.frame.origin.y+timeLabel.frame.size.height, timeLabel.frame.size.width, 20)];
    
    NSString *seatStr = @"";
    for (int i=0; i<self.selecetedSeats.count; i++) {
        int num = arc4random() % 100 ;
        seatStr = [seatStr stringByAppendingFormat:@"%@", [NSString stringWithFormat:@" %d",num]];
    }
    
    seatLabel.text = [NSString stringWithFormat:@"SEAT:%@",seatStr];
    seatLabel.font = [UIFont systemFontOfSize:14];
    seatLabel.textColor = [UIColor darkGrayColor];
    [self.view addSubview:seatLabel];
    
    UILabel *totalLabel = [[UILabel alloc]initWithFrame:CGRectMake(seatLabel.frame.origin.x, seatLabel.frame.origin.y+seatLabel.frame.size.height, seatLabel.frame.size.width, 20)];
    totalLabel.text = [NSString stringWithFormat:@"TOTAL:$%lu",self.selecetedSeats.count*20];
    totalLabel.font = [UIFont systemFontOfSize:14];
    totalLabel.textColor = [UIColor darkGrayColor];
    [self.view addSubview:totalLabel];
    
    UILabel *desLabel = [[UILabel alloc]initWithFrame:CGRectMake(15, totalLabel.frame.origin.y+totalLabel.frame.size.height, self.view.frame.size.width-30, 340)];
    desLabel.numberOfLines = 0;
    desLabel.text = [NSString stringWithFormat:@"%@",self.movieintroduction];
    desLabel.font = [UIFont systemFontOfSize:14];
    desLabel.textColor = [UIColor darkGrayColor];
//    [self.view addSubview:desLabel];
    
    UIImageView *bgVIew2 = [[UIImageView alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2-100, totalLabel.frame.origin.y+totalLabel.frame.size.height+20, 200, 120)];
    bgVIew2.image = [UIImage imageNamed:@"bg1"];
//    bgVIew.backgroundColor = [UIColor colorWithRed:240 green:244 blue:250 alpha:1];
    [self.view addSubview:bgVIew2];
}

@end
