//
//  PayViewController.m
//  A3
//
//  Created by 李志超 on 2022/5/20.
//

#import "PayViewController.h"
#import "TicketViewController.h"

@interface PayViewController ()

@end

@implementation PayViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.title = @"Confirm order";
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(15, 100, 100, 140)];
    imageView.image = self.movieimage;
    [self.view addSubview:imageView];
    
    UILabel *movieTitleLabel = [[UILabel alloc]initWithFrame:CGRectMake(imageView.frame.origin.x+imageView.frame.size.width+15, imageView.frame.origin.y, self.view.frame.size.width-100-50, 60)];
    movieTitleLabel.font = [UIFont boldSystemFontOfSize:24];
    movieTitleLabel.numberOfLines = 0;
    movieTitleLabel.text = self.movietitle;
    [self.view addSubview:movieTitleLabel];
    
    UILabel *dateLabel = [[UILabel alloc]initWithFrame:CGRectMake(movieTitleLabel.frame.origin.x, movieTitleLabel.frame.origin.y+movieTitleLabel.frame.size.height, movieTitleLabel.frame.size.width, 20)];
    dateLabel.text = [NSString stringWithFormat:@"DATE:%@",self.dateStr];
    dateLabel.font = [UIFont systemFontOfSize:14];
    dateLabel.textColor = [UIColor darkGrayColor];
    [self.view addSubview:dateLabel];
    
    UILabel *timeLabel = [[UILabel alloc]initWithFrame:CGRectMake(dateLabel.frame.origin.x, dateLabel.frame.origin.y+dateLabel.frame.size.height, dateLabel.frame.size.width, 20)];
    timeLabel.text = [NSString stringWithFormat:@"TIME:%@",self.timeStr];
    timeLabel.font = [UIFont systemFontOfSize:14];
    timeLabel.textColor = [UIColor darkGrayColor];
    [self.view addSubview:timeLabel];
    
    NSLog(@"%@",self.selecetedSeats);
    UILabel *seatLabel = [[UILabel alloc]initWithFrame:CGRectMake(timeLabel.frame.origin.x, timeLabel.frame.origin.y+timeLabel.frame.size.height, timeLabel.frame.size.width, 20)];
    
    NSString *seatStr = @"";
    for (int i=0; i<self.selecetedSeats.count; i++) {
        int num = arc4random() % 100 ;
        seatStr = [seatStr stringByAppendingFormat:@"%@", [NSString stringWithFormat:@" %d",num]];
    }
    
    seatLabel.text = [NSString stringWithFormat:@"SEAT:%@",seatStr];
    seatLabel.font = [UIFont systemFontOfSize:14];
    seatLabel.textColor = [UIColor darkGrayColor];
    [self.view addSubview:seatLabel];
    
    UILabel *totalLabel = [[UILabel alloc]initWithFrame:CGRectMake(seatLabel.frame.origin.x, seatLabel.frame.origin.y+seatLabel.frame.size.height, seatLabel.frame.size.width, 20)];
    totalLabel.text = [NSString stringWithFormat:@"TOTAL:$%lu",self.selecetedSeats.count*20];
    totalLabel.font = [UIFont systemFontOfSize:14];
    totalLabel.textColor = [UIColor darkGrayColor];
    [self.view addSubview:totalLabel];
    
    UILabel *desLabel = [[UILabel alloc]initWithFrame:CGRectMake(15, totalLabel.frame.origin.y+totalLabel.frame.size.height, self.view.frame.size.width-30, 340)];
    desLabel.numberOfLines = 0;
    desLabel.text = [NSString stringWithFormat:@"%@",self.movieintroduction];
    desLabel.font = [UIFont systemFontOfSize:14];
    desLabel.textColor = [UIColor darkGrayColor];
    [self.view addSubview:desLabel];
    
    UIButton *sureBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [sureBtn setTitle:@"Confirm" forState:UIControlStateNormal];
    sureBtn.titleLabel.adjustsFontSizeToFitWidth = YES;
    [sureBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [sureBtn addTarget:self action:@selector(sureBtnAction) forControlEvents:UIControlEventTouchUpInside];
    [sureBtn setBackgroundColor:[UIColor systemBlueColor]];
    sureBtn.layer.cornerRadius = 5;
    sureBtn.layer.masksToBounds = YES;
    sureBtn.frame = CGRectMake(self.view.frame.size.width/2-100, 600, 200, 50);
    [self.view addSubview:sureBtn];
}

- (void)sureBtnAction{
    TicketViewController *vc = [TicketViewController new];
    vc.movietitle = self.movietitle;
    vc.movieimage = self.movieimage;
    vc.movieintroduction = self.movieintroduction;
    vc.dateStr = self.dateStr;
    vc.placeStr = self.placeStr;
    vc.timeStr = self.timeStr;
    vc.selecetedSeats = self.selecetedSeats;
    [self.navigationController pushViewController:vc animated:YES];
}

@end
