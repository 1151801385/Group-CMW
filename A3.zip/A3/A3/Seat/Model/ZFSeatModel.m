//
//  ZFSeatModel.m
//  ZFSeatSelection
//
//  Created by © 2016年 qq 316917975  on 16/7/12.
//
//

#import "ZFSeatModel.h"

@implementation ZFSeatModel

@end
