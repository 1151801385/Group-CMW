//
//  ZFSeatsModel.m
//  ZFSeatSelection
//
//  Created by © 2016年 qq 316917975  on 16/7/12.
//
//

#import "ZFSeatsModel.h"

@implementation ZFSeatsModel
+(NSDictionary *)mj_objectClassInArray
{
    return @{
             @"columns":@"ZFSeatModel",
             };
}
@end
